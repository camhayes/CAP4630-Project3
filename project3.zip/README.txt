CAP4630 Project 3
Cam Hayes

Requirements:

install rich package
pip install rich

install pysat
pip install python-sat

To Use:
You may need to specify the parent directory when prompted for input file

example: 
> Enter hard contstraints file name: ../ExampleTestCase/constraints.txt         <= ../ExampleTestCase specified 

