CAP4630 Project 3
Cam Hayes

Requirements:

install rich package
pip install rich

install pysat
pip install python-sat

To Use:
This project uses a single file, main.py. Run python main.py in terminal to execute the program.

You may need to specify the parent directory when prompted for input file

example: 
> Enter hard contstraints file name: ../ExampleTestCase/constraints.txt         <= ../ExampleTestCase specified 

A copy of the main.py file is also available in the src directory. This is the same file found in root.